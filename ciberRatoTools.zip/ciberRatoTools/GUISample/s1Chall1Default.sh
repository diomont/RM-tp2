./GUISample --pos 1 --robname GUISample2 -m ../Labs/PathFinder/pathFinderDefault_lab.xml
