java jClient  -pos 1 -robname jClient1 &
java jClient  -pos 2 -robname jClient2 &
java jClient  -pos 3 -robname jClient3 &
java jClient  -pos 4 -robname jClient4 &
java jClient  -pos 5 -robname jClient5 &
