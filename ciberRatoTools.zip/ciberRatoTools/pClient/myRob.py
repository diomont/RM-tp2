
import sys
from typing import List, Literal, Tuple, Union
from croblink import *
from math import *


Coords = Tuple[int, int]

class MyRob(CRobLinkAngs):
    def __init__(self, rob_name, rob_id, angles, host):
        CRobLinkAngs.__init__(self, rob_name, rob_id, angles, host)

        self.nodemap = NodeMap()
        self.plan = []

        self.diameter = 1
        self.pose = [0, 0, 0]
        self.goal_thresh = 0.05


    def plan_final_path(self) -> List[Coords]:
        """Plans shortest path that passes through all spots, starting and ending on position 0"""

        # calculate shortest path between every pair of beacons and find smallest sum?

        pass

    def correct_estimation(self):
        """Uses line sensor and compass measures to correct its position and orientation estimate."""
        pass

    def move_by_plan(self):
        """
        Sends `driveMotors` command such that the robot drives to the next position in the current plan.
        The robot will only ever move up, down, left or right, decided by comparing the current position estimate with the current goal.
        When the distance between the position estimate and the goal is below a certain threshold, the goal is removed from the plan.

        Calling this method once will not complete all of the plan, rather it makes progress towards its next goal,
        such as rotating a small amount each call to face the next destination.
        It should be used in a `while` loop after a `readSensors` call, and as such allows for other code to run at each step of the plan execution.
        """

        dest = self.plan[0]
        x, y, th = self.pose
        # check if close enough to destination to remove from plan
        if abs(dest[0] - x) < self.goal_thresh and abs(dest[1] - y) < self.goal_thresh:
            self.plan.pop(0)
            if not self.plan: return
            dest = self.plan[0]

        # determine whether to rotate in place or go forward
        ang = atan2( dest[1]-y, dest[0]-x )
        if ang-th > 0.1:
            # destination is to the left of current orientation
            out1, out2 = -0.1, 0.1
        elif ang-th < -0.1:
            # destination is to the right of current orientation
            out1, out2 = 0.1, -0.1
        else:
            # distination is right ahead (...almost)
            out1, out2 = 0.1, 0.1

        # apply movement model to pose
        lin = (out1 + out2)/2
        new_x = x + lin*cos(th)
        new_y = y + lin*sin(th)
        new_th = th + (out2-out1)/self.diameter

        # TODO: check if wrapping orientation is necessary

        self.pose = [new_x, new_y, new_th]
        self.driveMotors(out1, out2)



    def update_map(self):
        """
        Uses the current sensor measures to update the map (locating spots, adding paths to map).
        """

        #curr_x = round(self.pose[0])
        #curr_y = round(self.pose[1])

        # determine robot facing
        tol = pi/2*0.1  # some tolerance in angle ranges

        # TODO: orientation is [-pi, pi] or [0, 2pi]?
        if pi/2-tol < self.pose[2] < pi/2+tol \
        or -pi/2-tol < self.pose[2] < -pi/2+tol:
            # facing up or down
            pass
        elif (pi-tol < self.pose[2] or self.pose[2] < -pi+tol) \
        or   -tol < self.pose[2] < tol:
            # facing left or right
            pass


        self.measures.lineSensor

        pass


    def run(self):
        if self.status != 0:
            print("Connection refused or error")
            quit()

        state = 'stop'
        stopped_state = 'run'
        phase = "exploring"


        while True:

            self.readSensors()
            self.correct_estimation()

            if state == 'stop' and self.measures.start:
                state = stopped_state

            if state != 'stop' and self.measures.stop:
                stopped_state = state
                state = 'stop'

            if state == "run":

                if phase == "exploring":
                    self.update_map()

                # always move according to plan if there is one
                if self.plan:
                    self.move_by_plan()
                # if there is no plan and there is still more to explore, get new destination
                elif phase == "exploring" and not self.nodemap.is_fully_explored():
                    curr_pos = (round(self.pose[0], round(self.pose[1])))
                    next_dest = self.nodemap.get_closest_unexplored(curr_pos)
                    self.plan = self.nodemap.plan_path(curr_pos, next_dest)

                    # TODO: spin in place to find paths


                # if there is no plan and there is no more to explore, then calculate path through all beacons and return to (0,0)
                elif phase == "exploring":
                    phase = "finalizing"
                    self.plan_final_path()
                    # TODO: write path to file
                    curr_pos = (round(self.pose[0], round(self.pose[1])))
                    self.plan = self.nodemap.plan_path(curr_pos, (0,0))
                    self.setReturningLed(True)
                # not exploring and no plan, meaning robot has returned to (0,0) and accomplished all tasks
                else:
                    self.finish()
                    quit()


    
    def test(self):

        state = 'stop'
        stopped_state = 'run'

        self.plan = [(2,0), (2,-2), (0,-2), (-2,-2), (-2,0), (-2,2)]

        while True:

            self.readSensors()

            if state == 'stop' and self.measures.start:
                state = stopped_state

            if state != 'stop' and self.measures.stop:
                stopped_state = state
                state = 'stop'

            if state == "run":
                if self.plan:
                    self.move_by_plan()
                    #print(self.pose)
                else:
                    self.finish()
                    quit()


class NodeMap():

    class Node():
        def __init__(self, coords, starting_edge = None) -> None:
            self.x = coords[0]
            self.y = coords[1]
            self.edges = [starting_edge] if starting_edge else []
            self.null_edges = set()  # can contain "up", "down", "left" and "right". their presence means that there is no path in that direction
        
        def add_edge(self, node):
            if node not in self.edges:
                self.edges.append(node)
        
        def add_null_edge(self, direction: Literal["up", "down", "left", "right"]):
            self.null_edges.add(direction)

        @property
        def explored(self):
            """A node is considered to be explored when 4 edges or null edges are known"""
            return len(self.edges) + len(self.null_edges) == 4
        
        def __eq__(self, __value: object) -> bool:
            return self.x == __value.x and self.y == __value.y


    def __init__(self) -> None:
        self.nodes = [] # index self.nodes with [x][y]
        self.node_coords = []  # stores internal coordinates of known nodes, not the world coordinates
        for _ in range(25):
            self.nodes.append([None]*11)

        start = self.Node((0,0))
        self.beacon_coords = {0: (0,0)}
        self.add_node(start)

    def add_node(self, node: Node, beacon_id = None):
        x,y = node.x, node.y
        x = x/2 + 5
        y = y/2 + 12
        self.nodes[x][y] = node
        self.node_coords.append((x,y))
        if beacon_id: self.beacon_coords[beacon_id] = (node.x, node.y)

    def get_node(self, coords: Coords) -> Union[Node, None]:
        x,y = coords
        x = x/2 + 5
        y = y/2 + 12
        return self.nodes[x][y]
    
    def add_new_path(self, origin: Coords, end: Coords):
        origin_node =  self.get_node(origin)
        end_node = self.get_node(end_node)
        if origin_node is None:
            origin_node = self.Node(origin)
            self.add_node(origin_node)
        if end_node is None:
            end_node = self.Node(end)
            self.add_node(end_node)
        
        origin_node.add_edge(end_node)
        end_node.add_edge(origin_node)

    def is_fully_explored(self) -> bool:
        return all( self.nodes[x][y].explored for x,y in self.node_coords )

    def get_closest_unexplored(self, curr: Coords) -> Coords:
        """Uses manhattan distance as heuristic to pick closest unexplored node"""
        best = None
        best_dist = 1000

        for x,y in self.node_coords:
            node = self.nodes[x][y]
            if node.explored or (node.x, node.y) == curr: continue

            distance = abs(curr[0] - node.x) + abs(curr[1] - node.y)

            if distance < best_dist:
                best = node
                best_dist = distance
        
        return (best.x, best.y)

    def plan_path(self, start: Coords, goal: Coords) -> List[Coords]:
        pass



rob_name = "pClient1"
host = "localhost"
pos = 1

for i in range(1, len(sys.argv),2):
    if (sys.argv[i] == "--host" or sys.argv[i] == "-h") and i != len(sys.argv) - 1:
        host = sys.argv[i + 1]
    elif (sys.argv[i] == "--pos" or sys.argv[i] == "-p") and i != len(sys.argv) - 1:
        pos = int(sys.argv[i + 1])
    elif (sys.argv[i] == "--robname" or sys.argv[i] == "-r") and i != len(sys.argv) - 1:
        rob_name = sys.argv[i + 1]
    else:
        print("Unkown argument", sys.argv[i])
        quit()

if __name__ == '__main__':
    rob=MyRob(rob_name,pos,[0.0,60.0,-60.0,180.0],host)
    
    #rob.run()
    rob.test()
